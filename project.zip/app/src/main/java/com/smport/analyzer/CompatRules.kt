package com.smport.analyzer

/**
 * Reglas para clasificar DLL importadas.
 *
 * IMPORTANTE: que una DLL aparezca en la tabla de importaciones es un hecho
 * comprobable ("confirmado"). Lo que significa para el port es una HIPÓTESIS
 * y se marca así en el informe.
 */
object CompatRules {
    class Rule(val prefix: String, val category: String, val hypothesis: String)

    private val rules = listOf(
        Rule("d3dcompiler", "Gráficos / shaders", "Compilador de shaders HLSL de Windows. En Android habría que usar shaders GLSL/SPIR-V (Vulkan) y reemplazar esta dependencia."),
        Rule("d3d9", "Gráficos Direct3D", "Direct3D 9: no existe en Android. Haría falta una capa o reescritura del render hacia Vulkan/OpenGL ES."),
        Rule("d3d10", "Gráficos Direct3D", "Direct3D 10: no existe en Android. Haría falta una capa o reescritura del render hacia Vulkan/OpenGL ES."),
        Rule("d3d11", "Gráficos Direct3D", "Direct3D 11: no existe en Android. Haría falta una capa o reescritura del render hacia Vulkan/OpenGL ES."),
        Rule("d3d12", "Gráficos Direct3D", "Direct3D 12: no existe en Android. Haría falta una capa o reescritura del render hacia Vulkan."),
        Rule("dxgi", "Gráficos Direct3D", "Infraestructura gráfica de DirectX (ventanas, swap chain). No existe en Android."),
        Rule("opengl32", "Gráficos OpenGL de escritorio", "OpenGL de escritorio: Android usa OpenGL ES, que es un subconjunto distinto."),
        Rule("glu32", "Gráficos OpenGL de escritorio", "Utilidades de OpenGL de escritorio; sin equivalente directo en Android."),
        Rule("vulkan", "Gráficos Vulkan", "Vulkan sí existe en Android, lo que podría facilitar un port del render (hipótesis)."),
        Rule("xinput", "Entrada", "Mando de Xbox en Windows. En Android se reemplaza por la API de entrada de Android."),
        Rule("dinput", "Entrada", "DirectInput de Windows. En Android se reemplaza por la API de entrada de Android."),
        Rule("xaudio2", "Audio", "Audio de DirectX. En Android se reemplaza por AAudio/OpenSL ES u otra biblioteca."),
        Rule("dsound", "Audio", "DirectSound de Windows. En Android se reemplaza por AAudio/OpenSL ES u otra biblioteca."),
        Rule("winmm", "Audio / multimedia Windows", "API multimedia de Windows (temporizadores, audio básico)."),
        Rule("fmod", "Audio (FMOD)", "FMOD es multiplataforma y tiene SDK para Android, pero es software con licencia: se necesitaría su SDK de Android (hipótesis)."),
        Rule("steam_api", "Steamworks", "API de Steam. Habría que eliminarla o sustituirla por otra capa."),
        Rule("steamclient", "Steamworks", "Cliente de Steam. Sin equivalente en Android."),
        Rule("assimp", "Importador de modelos 3D (Assimp)", "Assimp es de código abierto y multiplataforma; en principio se puede compilar para Android (hipótesis)."),
        Rule("physx", "Física", "Motor de física NVIDIA PhysX; existe una variante para Android, pero depende de la versión (hipótesis)."),
        Rule("bullet", "Física", "Bullet Physics es de código abierto y multiplataforma (hipótesis)."),
        Rule("lua", "Scripting", "Lua es de código abierto y multiplataforma (hipótesis)."),
        Rule("ws2_32", "Red", "Winsock. En Android se reemplaza por sockets POSIX (cambios moderados)."),
        Rule("wsock32", "Red", "Winsock. En Android se reemplaza por sockets POSIX (cambios moderados)."),
        Rule("wininet", "Red", "API de internet de Windows; hay que sustituirla."),
        Rule("winhttp", "Red", "API HTTP de Windows; hay que sustituirla."),
        Rule("msvcp", "Runtime C++ de Visual Studio", "Runtime de MSVC. En Android se usa la biblioteca C++ del NDK (libc++), lo que exige recompilar desde el código fuente."),
        Rule("vcruntime", "Runtime C++ de Visual Studio", "Runtime de MSVC. En Android se usa libc++ del NDK; exige recompilar desde el código fuente."),
        Rule("ucrtbase", "Runtime C de Windows", "Runtime C universal de Windows; en Android se usa bionic."),
        Rule("msvcr", "Runtime C de Visual Studio", "Runtime de MSVC; en Android se usa bionic."),
        Rule("api-ms-win", "API de Windows (API sets)", "Contratos internos de la API de Windows. Indican uso de funciones propias de Windows."),
        Rule("kernel32", "API de Windows (base)", "Núcleo de Windows (archivos, hilos, memoria). Hay que reemplazarlo por llamadas POSIX/Android."),
        Rule("user32", "API de Windows (ventanas/entrada)", "Ventanas y mensajes de Windows. En Android se reemplaza por Activity/NativeActivity."),
        Rule("gdi32", "API de Windows (gráficos GDI)", "Gráficos GDI de Windows; sin equivalente directo."),
        Rule("advapi32", "API de Windows (registro/seguridad)", "Registro y seguridad de Windows; hay que sustituirlos."),
        Rule("shell32", "API de Windows (shell)", "Funciones del shell de Windows (carpetas, rutas); hay que sustituirlas."),
        Rule("shlwapi", "API de Windows (shell)", "Utilidades de rutas de Windows; hay que sustituirlas."),
        Rule("ole32", "API de Windows (COM)", "COM de Windows; sin equivalente en Android."),
        Rule("oleaut32", "API de Windows (COM)", "COM de Windows; sin equivalente en Android."),
        Rule("ntdll", "API de Windows (núcleo)", "Interfaz interna del núcleo de Windows; sin equivalente en Android."),
        Rule("imm32", "API de Windows (entrada de texto)", "Métodos de entrada de Windows."),
        Rule("comdlg32", "API de Windows (diálogos)", "Diálogos comunes de Windows (abrir/guardar archivo)."),
        Rule("version", "API de Windows (versiones)", "Información de versión de archivos de Windows.")
    )

    fun classify(dll: String): Rule? {
        val l = dll.lowercase()
        return rules.firstOrNull { l.startsWith(it.prefix) }
    }
}
