package com.smport.analyzer

import org.json.JSONArray
import org.json.JSONObject
import java.io.EOFException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class PeSection(
    val name: String,
    val virtualAddress: Long,
    val virtualSize: Long,
    val rawOffset: Long,
    val rawSize: Long
)

class PeImport(
    val dll: String,
    val functions: List<String>,
    val totalFunctions: Int
)

class PeInfo(
    val valid: Boolean,
    val error: String?,
    val machine: String = "",
    val format: String = "",
    val isDll: Boolean = false,
    val subsystem: String = "",
    val timestamp: Long = 0L,
    val sections: List<PeSection> = emptyList(),
    val imports: List<PeImport> = emptyList(),
    val hasClr: Boolean = false,
    val importWarning: String? = null
) {
    fun toJson(maxFunctionsPerDll: Int): JSONObject {
        val o = JSONObject()
        o.put("pe_valido", valid)
        if (!valid) {
            o.put("error", error ?: "desconocido")
            return o
        }
        o.put("arquitectura", machine)
        o.put("formato", format)
        o.put("es_dll", isDll)
        o.put("subsistema", subsystem)
        o.put("tiene_clr_dotnet", hasClr)
        if (timestamp != 0L) {
            val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            f.timeZone = TimeZone.getTimeZone("UTC")
            o.put("timestamp_compilacion", f.format(Date(timestamp * 1000L)))
        }
        val secs = JSONArray()
        for (s in sections) {
            val so = JSONObject()
            so.put("nombre", s.name)
            so.put("tamano_virtual", s.virtualSize)
            so.put("tamano_en_disco", s.rawSize)
            secs.put(so)
        }
        o.put("secciones", secs)
        val imps = JSONArray()
        for (i in imports) {
            val io = JSONObject()
            io.put("dll", i.dll)
            io.put("funciones_total", i.totalFunctions)
            val fa = JSONArray()
            for (fn in i.functions.take(maxFunctionsPerDll)) fa.put(fn)
            io.put("funciones", fa)
            imps.put(io)
        }
        o.put("importaciones", imps)
        if (importWarning != null) o.put("aviso_importaciones", importWarning)
        return o
    }
}

/**
 * Analizador mínimo de ficheros PE (Windows). Solo LEE cabeceras y tablas;
 * nunca ejecuta nada del archivo analizado.
 */
object PeAnalyzer {
    private const val MAX_IMPORT_DLLS = 512
    private const val MAX_THUNKS = 4000
    private const val MAX_FUNCS_KEPT = 400

    fun analyze(ch: FileChannel): PeInfo {
        try {
            val size = ch.size()
            if (size < 64) return PeInfo(false, "Archivo demasiado pequeño para ser PE")

            val dos = read(ch, 0, 64)
            if ((dos.getShort(0).toInt() and 0xFFFF) != 0x5A4D) {
                return PeInfo(false, "No tiene la firma MZ (no es un ejecutable/DLL de Windows)")
            }
            val peOff = dos.getInt(0x3C).toLong() and 0xFFFFFFFFL
            if (peOff < 64 || peOff + 24 > size) return PeInfo(false, "Cabecera PE fuera de rango")

            val coff = read(ch, peOff, 24)
            if (coff.getInt(0) != 0x00004550) return PeInfo(false, "Firma PE no encontrada")

            val machineCode = coff.getShort(4).toInt() and 0xFFFF
            val numSections = coff.getShort(6).toInt() and 0xFFFF
            val ts = coff.getInt(8).toLong() and 0xFFFFFFFFL
            val sizeOpt = coff.getShort(20).toInt() and 0xFFFF
            val characteristics = coff.getShort(22).toInt() and 0xFFFF
            val isDll = (characteristics and 0x2000) != 0

            if (sizeOpt < 96) return PeInfo(false, "Cabecera opcional ausente o demasiado corta")
            val optOff = peOff + 24
            val optLen = minOf(sizeOpt, 240)
            if (optOff + optLen > size) return PeInfo(false, "Cabecera opcional fuera de rango")
            val opt = read(ch, optOff, optLen)

            val magic = opt.getShort(0).toInt() and 0xFFFF
            val plus: Boolean = when (magic) {
                0x10B -> false
                0x20B -> true
                else -> return PeInfo(false, "Magic de cabecera opcional desconocido: 0x" + Integer.toHexString(magic))
            }
            val subsystemCode = opt.getShort(68).toInt() and 0xFFFF
            val numRvaOffset = if (plus) 108 else 92
            val dirBase = if (plus) 112 else 96
            val numRva = if (numRvaOffset + 4 <= optLen) opt.getInt(numRvaOffset) else 0

            fun dataDir(index: Int): LongArray? {
                if (index >= numRva) return null
                val o = dirBase + index * 8
                if (o + 8 > optLen) return null
                val rva = opt.getInt(o).toLong() and 0xFFFFFFFFL
                val sz = opt.getInt(o + 4).toLong() and 0xFFFFFFFFL
                if (rva == 0L) return null
                return longArrayOf(rva, sz)
            }

            val secCount = minOf(numSections, 96)
            val secOff = optOff + sizeOpt
            if (secOff + secCount * 40L > size) return PeInfo(false, "Tabla de secciones fuera de rango")
            val secBuf = read(ch, secOff, secCount * 40)
            val sections = ArrayList<PeSection>()
            for (i in 0 until secCount) {
                val b = i * 40
                val nameBytes = ByteArray(8)
                for (k in 0 until 8) nameBytes[k] = secBuf.get(b + k)
                var end = 0
                while (end < 8 && nameBytes[end].toInt() != 0) end++
                sections.add(
                    PeSection(
                        name = String(nameBytes, 0, end, Charsets.ISO_8859_1),
                        virtualSize = secBuf.getInt(b + 8).toLong() and 0xFFFFFFFFL,
                        virtualAddress = secBuf.getInt(b + 12).toLong() and 0xFFFFFFFFL,
                        rawSize = secBuf.getInt(b + 16).toLong() and 0xFFFFFFFFL,
                        rawOffset = secBuf.getInt(b + 20).toLong() and 0xFFFFFFFFL
                    )
                )
            }

            var imports: List<PeImport> = emptyList()
            var warning: String? = null
            val impDir = dataDir(1)
            if (impDir != null) {
                try {
                    imports = parseImports(ch, size, sections, impDir[0], plus)
                } catch (e: Exception) {
                    warning = "No se pudo leer toda la tabla de importaciones: " + (e.message ?: e.javaClass.simpleName)
                }
            }

            return PeInfo(
                valid = true,
                error = null,
                machine = machineName(machineCode),
                format = if (plus) "PE32+ (64 bits)" else "PE32 (32 bits)",
                isDll = isDll,
                subsystem = subsystemName(subsystemCode),
                timestamp = ts,
                sections = sections,
                imports = imports,
                hasClr = dataDir(14) != null,
                importWarning = warning
            )
        } catch (e: Exception) {
            return PeInfo(false, "Error al leer el archivo: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    private fun parseImports(
        ch: FileChannel,
        size: Long,
        sections: List<PeSection>,
        importRva: Long,
        plus: Boolean
    ): List<PeImport> {
        val result = ArrayList<PeImport>()
        val base = rvaToOffset(sections, importRva) ?: return result
        val thunkSize = if (plus) 8 else 4

        for (i in 0 until MAX_IMPORT_DLLS) {
            val dOff = base + i * 20L
            if (dOff + 20 > size) break
            val d = read(ch, dOff, 20)
            val origFirst = d.getInt(0).toLong() and 0xFFFFFFFFL
            val nameRva = d.getInt(12).toLong() and 0xFFFFFFFFL
            val first = d.getInt(16).toLong() and 0xFFFFFFFFL
            if (origFirst == 0L && nameRva == 0L && first == 0L) break

            val nameOff = rvaToOffset(sections, nameRva) ?: continue
            val dll = readCString(ch, nameOff, size)
            val thunkRva = if (origFirst != 0L) origFirst else first

            val funcs = ArrayList<String>()
            var total = 0
            val tOff = rvaToOffset(sections, thunkRva)
            if (tOff != null) {
                val len = minOf(MAX_THUNKS * thunkSize.toLong(), size - tOff).toInt()
                if (len >= thunkSize) {
                    val t = read(ch, tOff, len)
                    var p = 0
                    while (p + thunkSize <= len) {
                        val v: Long = if (plus) t.getLong(p) else (t.getInt(p).toLong() and 0xFFFFFFFFL)
                        if (v == 0L) break
                        total++
                        val isOrdinal = if (plus) v < 0 else (v and 0x80000000L) != 0L
                        if (funcs.size < MAX_FUNCS_KEPT) {
                            if (isOrdinal) {
                                funcs.add("#" + (v and 0xFFFFL))
                            } else {
                                val nOff = rvaToOffset(sections, v and 0x7FFFFFFFL)
                                if (nOff != null) funcs.add(readCString(ch, nOff + 2, size))
                            }
                        }
                        p += thunkSize
                    }
                }
            }
            result.add(PeImport(dll, funcs, total))
        }
        return result
    }

    private fun rvaToOffset(sections: List<PeSection>, rva: Long): Long? {
        for (s in sections) {
            val span = maxOf(s.virtualSize, s.rawSize)
            if (rva >= s.virtualAddress && rva < s.virtualAddress + span) {
                return s.rawOffset + (rva - s.virtualAddress)
            }
        }
        if (sections.isEmpty()) return rva
        val firstVa = sections.minOf { it.virtualAddress }
        return if (rva < firstVa) rva else null
    }

    private fun readCString(ch: FileChannel, off: Long, size: Long): String {
        val len = minOf(260L, size - off).toInt()
        if (len <= 0) return ""
        val b = read(ch, off, len)
        var end = 0
        while (end < len && b.get(end).toInt() != 0) end++
        val bytes = ByteArray(end)
        for (k in 0 until end) bytes[k] = b.get(k)
        return String(bytes, Charsets.ISO_8859_1)
    }

    private fun read(ch: FileChannel, pos: Long, len: Int): ByteBuffer {
        val buf = ByteBuffer.allocate(len).order(ByteOrder.LITTLE_ENDIAN)
        var p = pos
        while (buf.hasRemaining()) {
            val n = ch.read(buf, p)
            if (n < 0) throw EOFException("Fin de archivo inesperado en la posición $pos")
            p += n
        }
        buf.flip()
        return buf
    }

    private fun machineName(code: Int): String = when (code) {
        0x014C -> "x86 (i386)"
        0x8664 -> "x86-64 (AMD64)"
        0xAA64 -> "ARM64"
        0x01C0 -> "ARM"
        0x01C4 -> "ARM Thumb-2 (ARMNT)"
        0x0200 -> "Itanium"
        else -> "Desconocida (0x" + Integer.toHexString(code) + ")"
    }

    private fun subsystemName(code: Int): String = when (code) {
        1 -> "Native"
        2 -> "Windows GUI"
        3 -> "Windows consola (CUI)"
        else -> "Otro ($code)"
    }
}
