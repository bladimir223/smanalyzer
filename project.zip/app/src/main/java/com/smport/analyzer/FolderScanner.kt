package com.smport.analyzer

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object FolderScanner {
    private const val VERSION = "0.2.0"
    private const val NO_EXT = "(sin extensión)"
    private const val MAX_PE_FILES = 600
    private const val MAX_FUNCS_IN_REPORT = 300
    private val PE_EXT = setOf("exe", "dll", "sys", "ocx")

    private class Node(val docId: String, val rel: String, val top: String)
    private class PeEntry(val rel: String, val docId: String, val size: Long)
    private class Big(val path: String, val size: Long)

    // ------------------------------------------------------------------
    // Escaneo de carpeta completa
    // ------------------------------------------------------------------
    fun scan(ctx: Context, tree: Uri, onProgress: (String) -> Unit): JSONObject {
        val resolver = ctx.contentResolver
        val rootId = DocumentsContract.getTreeDocumentId(tree)

        val extStats = HashMap<String, LongArray>()
        val topStats = HashMap<String, LongArray>()
        val peEntries = ArrayList<PeEntry>()
        val biggest = ArrayList<Big>()
        val errors = JSONArray()
        var fileCount = 0L
        var dirCount = 0L
        var totalBytes = 0L

        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )

        val stack = ArrayList<Node>()
        stack.add(Node(rootId, "", ""))

        while (stack.isNotEmpty()) {
            val n = stack.removeAt(stack.size - 1)
            val childUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, n.docId)
            try {
                resolver.query(childUri, projection, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2) ?: ""
                        val size = if (c.isNull(3)) 0L else c.getLong(3)
                        val rel = if (n.rel.isEmpty()) name else n.rel + "/" + name
                        val isDir = mime == DocumentsContract.Document.MIME_TYPE_DIR
                        val childTop = if (n.rel.isEmpty()) (if (isDir) name else "(raíz)") else n.top

                        if (isDir) {
                            dirCount++
                            stack.add(Node(id, rel, childTop))
                        } else {
                            fileCount++
                            totalBytes += size
                            val dot = name.lastIndexOf('.')
                            val ext = if (dot > 0 && dot < name.length - 1) name.substring(dot + 1).lowercase() else NO_EXT

                            val es = extStats.getOrPut(ext) { LongArray(2) }
                            es[0] = es[0] + 1L
                            es[1] = es[1] + size
                            val ts = topStats.getOrPut(childTop) { LongArray(2) }
                            ts[0] = ts[0] + 1L
                            ts[1] = ts[1] + size

                            val looksPe = ext in PE_EXT ||
                                (ext == NO_EXT && name.lowercase().contains("scrapmechanic"))
                            if (looksPe) peEntries.add(PeEntry(rel, id, size))

                            biggest.add(Big(rel, size))
                            if (biggest.size > 200) {
                                biggest.sortByDescending { it.size }
                                while (biggest.size > 30) biggest.removeAt(biggest.size - 1)
                            }
                            if (fileCount % 500L == 0L) {
                                onProgress("Escaneando… $fileCount archivos, $dirCount carpetas")
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                if (errors.length() < 20) {
                    errors.put("No se pudo listar '" + n.rel + "': " + (e.message ?: e.javaClass.simpleName))
                }
            }
        }
        onProgress("Escaneo terminado: $fileCount archivos. Analizando binarios de Windows…")

        // --- Fase 2: análisis PE ---
        val toAnalyze = peEntries.sortedBy { it.rel.lowercase() }.take(MAX_PE_FILES)
        val peArray = JSONArray()
        val dllUsers = HashMap<String, Int>()
        val archCount = HashMap<String, Int>()
        var invalidPe = 0

        for ((idx, e) in toAnalyze.withIndex()) {
            onProgress("Analizando binarios ${idx + 1}/${toAnalyze.size}: ${e.rel}")
            val o = JSONObject()
            o.put("ruta", e.rel)
            o.put("tamano", e.size)
            try {
                val docUri = DocumentsContract.buildDocumentUriUsingTree(tree, e.docId)
                val pfd = resolver.openFileDescriptor(docUri, "r")
                if (pfd == null) {
                    o.put("pe_valido", false)
                    o.put("error", "No se pudo abrir el archivo")
                    invalidPe++
                } else {
                    pfd.use {
                        FileInputStream(it.fileDescriptor).use { fis ->
                            val info = PeAnalyzer.analyze(fis.channel)
                            val j = info.toJson(MAX_FUNCS_IN_REPORT)
                            val keys = j.keys()
                            while (keys.hasNext()) {
                                val k = keys.next()
                                o.put(k, j.get(k))
                            }
                            if (info.valid) {
                                archCount[info.machine] = (archCount[info.machine] ?: 0) + 1
                                val seen = HashSet<String>()
                                for (imp in info.imports) seen.add(imp.dll.lowercase())
                                for (d in seen) dllUsers[d] = (dllUsers[d] ?: 0) + 1
                            } else {
                                invalidPe++
                            }
                        }
                    }
                }
            } catch (ex: Exception) {
                o.put("pe_valido", false)
                o.put("error", ex.message ?: ex.javaClass.simpleName)
                invalidPe++
            }
            peArray.put(o)
        }

        // --- Compatibilidad ---
        val compat = JSONArray()
        for ((dll, count) in dllUsers.entries.sortedByDescending { it.value }) {
            val rule = CompatRules.classify(dll)
            val c = JSONObject()
            c.put("dll", dll)
            c.put("hecho_confirmado", "Aparece en la tabla de importaciones de $count binario(s) analizado(s).")
            c.put("categoria", rule?.category ?: "Sin clasificar")
            c.put("hipotesis_no_confirmada", rule?.hypothesis ?: "Sin regla: revisar manualmente.")
            compat.put(c)
        }

        // --- Avisos ---
        val warnings = JSONArray()
        warnings.put("Este informe describe archivos y dependencias. NO demuestra que el juego pueda portarse a Android.")
        warnings.put("Un .exe de Windows no se convierte en app Android por cambiar de arquitectura; un port real requiere código fuente.")
        if (fileCount == 0L) {
            warnings.put("No se encontraron archivos. Elige la carpeta correcta; Android no deja elegir la raíz de Download ni Android/data.")
        }
        if (peEntries.size > MAX_PE_FILES) {
            warnings.put("Solo se analizaron los primeros $MAX_PE_FILES de ${peEntries.size} binarios.")
        }
        if (toAnalyze.isNotEmpty() && !archCount.containsKey("ARM64")) {
            warnings.put("Ningún binario analizado es ARM64: todos son de arquitectura Windows/x86.")
        }

        // --- Armado del informe ---
        val report = JSONObject()
        report.put("tipo", "carpeta")
        report.put("herramienta", "SM Analyzer")
        report.put("version", VERSION)
        report.put("generado_utc", nowUtc())

        val resumen = JSONObject()
        resumen.put("archivos", fileCount)
        resumen.put("carpetas", dirCount)
        resumen.put("bytes_totales", totalBytes)
        resumen.put("binarios_pe_candidatos", peEntries.size)
        resumen.put("binarios_pe_analizados", toAnalyze.size)
        resumen.put("binarios_no_validos", invalidPe)
        val arch = JSONObject()
        for ((k, v) in archCount) arch.put(k, v)
        resumen.put("arquitecturas", arch)
        report.put("resumen", resumen)

        val topArr = JSONArray()
        for ((name, st) in topStats.entries.sortedByDescending { it.value[1] }) {
            val o = JSONObject()
            o.put("nombre", name)
            o.put("archivos", st[0])
            o.put("bytes", st[1])
            topArr.put(o)
        }
        report.put("carpetas_primer_nivel", topArr)

        val extArr = JSONArray()
        for ((ext, st) in extStats.entries.sortedByDescending { it.value[1] }.take(40)) {
            val o = JSONObject()
            o.put("extension", ext)
            o.put("archivos", st[0])
            o.put("bytes", st[1])
            extArr.put(o)
        }
        report.put("por_extension", extArr)

        biggest.sortByDescending { it.size }
        val bigArr = JSONArray()
        for (b in biggest.take(30)) {
            val o = JSONObject()
            o.put("ruta", b.path)
            o.put("bytes", b.size)
            bigArr.put(o)
        }
        report.put("archivos_mas_grandes", bigArr)

        report.put("binarios_pe", peArray)
        report.put("compatibilidad", compat)
        report.put("avisos", warnings)
        report.put("errores", errors)
        return report
    }

    // ------------------------------------------------------------------
    // Análisis de un solo archivo (.exe / .dll)
    // ------------------------------------------------------------------
    fun analyzeSingle(ctx: Context, uri: Uri): JSONObject {
        val resolver = ctx.contentResolver
        var name = "archivo"
        var size = 0L
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                c.getString(0)?.let { name = it }
                if (!c.isNull(1)) size = c.getLong(1)
            }
        }
        val report = JSONObject()
        report.put("tipo", "archivo")
        report.put("herramienta", "SM Analyzer")
        report.put("version", VERSION)
        report.put("generado_utc", nowUtc())
        report.put("archivo", name)
        report.put("tamano", size)

        val pfd = resolver.openFileDescriptor(uri, "r")
        if (pfd == null) {
            report.put("pe_valido", false)
            report.put("error", "No se pudo abrir el archivo")
            return report
        }
        pfd.use {
            FileInputStream(it.fileDescriptor).use { fis ->
                val info = PeAnalyzer.analyze(fis.channel)
                val j = info.toJson(MAX_FUNCS_IN_REPORT)
                val keys = j.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    report.put(k, j.get(k))
                }
            }
        }
        return report
    }

    // ------------------------------------------------------------------
    // Texto legible para mostrar en pantalla
    // ------------------------------------------------------------------
    fun summarize(r: JSONObject): String {
        val sb = StringBuilder()
        val res = r.getJSONObject("resumen")

        sb.append("RESUMEN\n")
        sb.append("Archivos: ").append(res.getLong("archivos")).append("\n")
        sb.append("Carpetas: ").append(res.getLong("carpetas")).append("\n")
        sb.append("Tamaño total: ").append(formatBytes(res.getLong("bytes_totales"))).append("\n")

        val top = r.getJSONArray("carpetas_primer_nivel")
        sb.append("\nCARPETAS DE PRIMER NIVEL\n")
        for (i in 0 until top.length()) {
            val o = top.getJSONObject(i)
            sb.append("• ${o.getString("nombre")}: ${o.getLong("archivos")} archivos, ${formatBytes(o.getLong("bytes"))}\n")
        }

        val ext = r.getJSONArray("por_extension")
        sb.append("\nEXTENSIONES PRINCIPALES (por tamaño)\n")
        for (i in 0 until minOf(ext.length(), 15)) {
            val o = ext.getJSONObject(i)
            sb.append("• .${o.getString("extension")}: ${o.getLong("archivos")} archivos, ${formatBytes(o.getLong("bytes"))}\n")
        }

        sb.append("\nBINARIOS DE WINDOWS\n")
        sb.append("Analizados: ${res.getInt("binarios_pe_analizados")} · No válidos: ${res.getInt("binarios_no_validos")}\n")
        val arch = res.getJSONObject("arquitecturas")
        val ak = arch.keys()
        while (ak.hasNext()) {
            val k = ak.next()
            sb.append("• $k: ${arch.getInt(k)}\n")
        }

        val pes = r.getJSONArray("binarios_pe")
        for (i in 0 until pes.length()) {
            val o = pes.getJSONObject(i)
            if (o.getString("ruta").lowercase().contains("scrapmechanic") && o.optBoolean("pe_valido", false)) {
                sb.append("\nEJECUTABLE PRINCIPAL: ${o.getString("ruta")}\n")
                sb.append("• Arquitectura: ${o.optString("arquitectura")}\n")
                sb.append("• Formato: ${o.optString("formato")}\n")
                sb.append("• Subsistema: ${o.optString("subsistema")}\n")
                val imps = o.optJSONArray("importaciones")
                if (imps != null) {
                    sb.append("• DLL importadas: ${imps.length()}\n")
                    val names = ArrayList<String>()
                    for (j in 0 until imps.length()) names.add(imps.getJSONObject(j).getString("dll"))
                    sb.append("  ").append(names.joinToString(", ")).append("\n")
                }
                break
            }
        }

        val compat = r.getJSONArray("compatibilidad")
        val byCat = LinkedHashMap<String, MutableList<String>>()
        for (i in 0 until compat.length()) {
            val c = compat.getJSONObject(i)
            byCat.getOrPut(c.getString("categoria")) { ArrayList() }.add(c.getString("dll"))
        }
        sb.append("\nDEPENDENCIAS IMPORTADAS POR CATEGORÍA (hecho confirmado)\n")
        for ((cat, dlls) in byCat) {
            sb.append("• $cat: ${dlls.take(8).joinToString(", ")}")
            if (dlls.size > 8) sb.append(" … (+${dlls.size - 8})")
            sb.append("\n")
        }
        sb.append("El detalle de lo que implica para el port está en el JSON, marcado como hipótesis.\n")

        val warn = r.getJSONArray("avisos")
        sb.append("\nAVISOS\n")
        for (i in 0 until warn.length()) sb.append("• ").append(warn.getString(i)).append("\n")

        val errs = r.getJSONArray("errores")
        if (errs.length() > 0) {
            sb.append("\nERRORES AL LEER\n")
            for (i in 0 until errs.length()) sb.append("• ").append(errs.getString(i)).append("\n")
        }
        return sb.toString()
    }

    fun summarizeSingle(r: JSONObject): String {
        val sb = StringBuilder()
        sb.append("ARCHIVO: ${r.optString("archivo")} (${formatBytes(r.optLong("tamano"))})\n\n")
        if (!r.optBoolean("pe_valido", false)) {
            sb.append("No es un PE válido.\nMotivo: ${r.optString("error", "desconocido")}\n")
            return sb.toString()
        }
        sb.append("Arquitectura: ${r.optString("arquitectura")}\n")
        sb.append("Formato: ${r.optString("formato")}\n")
        sb.append("Tipo: ${if (r.optBoolean("es_dll")) "DLL" else "Ejecutable"}\n")
        sb.append("Subsistema: ${r.optString("subsistema")}\n")
        if (r.has("timestamp_compilacion")) sb.append("Compilado (UTC): ${r.optString("timestamp_compilacion")}\n")
        if (r.optBoolean("tiene_clr_dotnet")) sb.append("Contiene cabecera .NET (CLR)\n")

        val secs = r.optJSONArray("secciones")
        if (secs != null) {
            val names = ArrayList<String>()
            for (i in 0 until secs.length()) names.add(secs.getJSONObject(i).getString("nombre"))
            sb.append("Secciones (${secs.length()}): ${names.joinToString(" ")}\n")
        }

        val imps = r.optJSONArray("importaciones")
        val cats = LinkedHashMap<String, String>()
        if (imps != null) {
            sb.append("\nIMPORTACIONES (${imps.length()} DLL)\n")
            for (i in 0 until imps.length()) {
                val o = imps.getJSONObject(i)
                val dll = o.getString("dll")
                val rule = CompatRules.classify(dll)
                sb.append("• $dll [${rule?.category ?: "Sin clasificar"}] — ${o.getInt("funciones_total")} funciones\n")
                val fa = o.getJSONArray("funciones")
                val first = ArrayList<String>()
                for (j in 0 until minOf(fa.length(), 12)) first.add(fa.getString(j))
                if (first.isNotEmpty()) sb.append("    ").append(first.joinToString(", ")).append("\n")
                if (rule != null) cats[rule.category] = rule.hypothesis
            }
        }
        if (r.has("aviso_importaciones")) sb.append("\nAviso: ${r.optString("aviso_importaciones")}\n")

        if (cats.isNotEmpty()) {
            sb.append("\nQUÉ PODRÍA SIGNIFICAR (hipótesis, NO confirmado)\n")
            for ((cat, hyp) in cats) sb.append("• $cat: $hyp\n")
        }
        sb.append("\nRecuerda: esto solo describe el archivo. No demuestra que se pueda portar a Android.\n")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    private fun nowUtc(): String {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date())
    }

    private fun formatBytes(b: Long): String {
        if (b < 1024) return "$b B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = b.toDouble()
        var i = -1
        while (v >= 1024 && i < units.size - 1) {
            v /= 1024
            i++
        }
        return String.format(Locale.US, "%.1f %s", v, units[i])
    }
}
