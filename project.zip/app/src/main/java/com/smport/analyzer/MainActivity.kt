package com.smport.analyzer

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val reqFolder = 1
    private val reqFile = 2
    private val reqSave = 3

    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var btnFolder: Button
    private lateinit var btnFile: Button
    private lateinit var btnSave: Button

    private var lastReport: JSONObject? = null
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(16)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "SM Analyzer 0.2"
        title.textSize = 22f
        title.setTypeface(title.typeface, Typeface.BOLD)
        root.addView(title)

        val sub = TextView(this)
        sub.text = "Analiza la carpeta de un juego o un .exe/.dll de Windows. " +
            "Solo lee archivos: no ejecuta nada y no modifica nada."
        sub.setPadding(0, dp(4), 0, dp(12))
        root.addView(sub)

        btnFolder = Button(this)
        btnFolder.text = "1) Analizar carpeta del juego"
        btnFolder.setOnClickListener { pickFolder() }
        root.addView(btnFolder)

        btnFile = Button(this)
        btnFile.text = "2) Analizar un .exe / .dll"
        btnFile.setOnClickListener { pickFile() }
        root.addView(btnFile)

        btnSave = Button(this)
        btnSave.text = "3) Guardar informe JSON"
        btnSave.isEnabled = false
        btnSave.setOnClickListener { saveReport() }
        root.addView(btnSave)

        status = TextView(this)
        status.text = "Elige una opción para empezar."
        status.setPadding(0, dp(12), 0, dp(8))
        root.addView(status)

        output = TextView(this)
        output.typeface = Typeface.MONOSPACE
        output.textSize = 12f
        output.setTextIsSelectable(true)
        root.addView(output)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun pickFolder() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), reqFolder)
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, reqFile)
    }

    private fun saveReport() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/json"
        i.putExtra(Intent.EXTRA_TITLE, "informe_sm_analyzer.json")
        startActivityForResult(i, reqSave)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uri: Uri = data.data ?: return
        when (requestCode) {
            reqFolder -> {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                    // No es imprescindible conservar el permiso.
                }
                runJob("Escaneando carpeta…") {
                    FolderScanner.scan(this, uri) { p -> postStatus(p) }
                }
            }
            reqFile -> runJob("Analizando archivo…") {
                FolderScanner.analyzeSingle(this, uri)
            }
            reqSave -> writeReport(uri)
        }
    }

    private fun postStatus(text: String) {
        runOnUiThread { status.text = text }
    }

    private fun setBusy(busy: Boolean) {
        btnFolder.isEnabled = !busy
        btnFile.isEnabled = !busy
        btnSave.isEnabled = !busy && lastReport != null
    }

    private fun runJob(startText: String, job: () -> JSONObject) {
        status.text = startText
        output.text = ""
        setBusy(true)
        executor.execute {
            try {
                val rep = job()
                val text = if (rep.optString("tipo") == "carpeta") {
                    FolderScanner.summarize(rep)
                } else {
                    FolderScanner.summarizeSingle(rep)
                }
                runOnUiThread {
                    lastReport = rep
                    output.text = text
                    status.text = "Listo. Puedes guardar el informe JSON con el botón 3."
                    setBusy(false)
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    status.text = "Error: " + (t.message ?: t.javaClass.simpleName)
                    setBusy(false)
                }
            }
        }
    }

    private fun writeReport(uri: Uri) {
        val rep = lastReport ?: return
        executor.execute {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use {
                    it.write(rep.toString(2).toByteArray(Charsets.UTF_8))
                }
                postStatus("Informe guardado correctamente.")
            } catch (t: Throwable) {
                postStatus("No se pudo guardar: " + (t.message ?: t.javaClass.simpleName))
            }
        }
    }
}
